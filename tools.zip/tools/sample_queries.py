"""
Copyright <2023> <Andreas Niskanen, University of Helsinki>

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be included in all copies
or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
"""

import random
import os

random.seed(811543731122527)
instance_folder = "iccma23-benchmark-set"

for file in sorted(os.listdir(instance_folder)):
	if not file.endswith(".af"):
		continue
	lines = [line for line in open(instance_folder + "/" + file).read().split("\n") if len(line) > 0]
	lines = [line.strip() for line in lines if not line.startswith("#")]
	first_line = lines[0]
	n_args = int(first_line.replace("p af ", ""))
	self_attack = { i : False for i in range(1, n_args+1) }
	indegree = { i : 0 for i in range(1, n_args+1) }
	for line in lines[1:]:
		line_split = line.split()
		source = int(line_split[0])
		target = int(line_split[1])
		if source == target:
			self_attack[source] = True
		indegree[target] += 1
	query = 0
	attempts = 0
	while True:
		query = random.randint(1, n_args)
		attempts += 1
		if not self_attack[query] and indegree[query] > 0:
			break
	query_file = open(instance_folder + "/" + file + ".arg", "w")
	query_file.write(str(query))
	query_file.close()
