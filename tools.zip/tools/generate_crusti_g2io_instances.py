"""
Copyright <2023> <Andreas Niskanen, University of Helsinki>

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be included in all copies
or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
"""

import random
import subprocess

crusti_g2io = "crusti_g2io/target/release/crusti_g2io"

random.seed(811543731122527)

params = [(175, 0.2, 511), (125, 0.5, 31), (225, 0.1, 31), (250, 0.2, 255)]
params += [(150, 0.1, 255), (225, 0.2, 127), (200, 0.1, 127), (300, 0.2, 255), (350, 0.5, 255)]

instances_per_param = 50
instance_folder = "crusti_g2io-benchmark-set"

for nodes, prob, communities in params:
	print(nodes, prob, communities)
	for i in range(instances_per_param):
		seed = random.randint(0, 2**31-1)
		subprocess.run([crusti_g2io, "generate-directed", "-x", instance_folder + "/" + "crusti_g2io_" + str(nodes) + "_" + str(prob) + "_" + str(communities) + "_" + str(i) + ".af", "-f", "iccma_dimacs", "-i", "er/" + str(nodes) + "," + str(prob), "-l", "random/0.2", "-o", "tree/" + str(communities), "-s", str(seed), "--logging-level", "off"])
