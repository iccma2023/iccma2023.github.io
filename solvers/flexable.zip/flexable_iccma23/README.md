# flexABle @ ICCMA 2023

## Running<a name="Running"></a>

`flexABle` is provided as a JAR file ([`flexable-assembly-1.0.jar`](flexable-assembly-1.0.jar)) and therefore need not compiling to be executed, provided that `JAVA 8` (`JDK 1.8`) (or higher) is accessible in the terminal (added to `$PATH`). 

In order to comply with the interface defined in the _solver requirements_, `flexABle` should be executed using a "wrapper" bash file [`flexable.sh`](flexable.sh), precisely as described in the _solver requirements_, i.e.

- to view general solver info
   
   ```user$ ./flexable.sh```

- to view the list of supported problems
   
   ```user$ ./flexable.sh --problems```

- to run `flexABle` given a task <TASK>, file <FILE> and a query <QUERY>
   
   ```user$ ./flexable.sh -p <TASK> -f <FILE> -a <QUERY>```

    e.g.

    ```user$ ./flexable.sh -p DC-CO -f examples/ex1.iccma -a 1```


## [Optional] Building 

As mentioned above ([Running](#Running)) `flexABle` need not being build as it is provided as a JAR file. Should that still be necessary, in order to build `flexABle`:

1.  install `SBT` version 1.8.2 or higher (https://www.scala-sbt.org/download.html)
2. extract the [src_code.zip](src_code.zip) directory and open the terminal within it
3. run `sbt assembly` - this will generate the JAR file `flexable-assembly-1.0.jar` inside `target/scala-2.13`
4. Place the resulting JAR file in the same directory as `flexable.sh`


## Requirements
- Running - `JAVA 8` (`JDK 1.8`) or higher
- [Optional] Building - `SBT 1.8.2` or higher

## Used external libraries
`flexABle` does not make use of any other external libraries except for the following:
- [`scala-parser-combinators`](https://github.com/scala/scala-parser-combinators) - to parse input files
- [`scalatest`](https://www.scalatest.org/) - for unit tests
- [`scopt_2.13`](https://github.com/scopt/scopt) - to parse input CLI parameters

none of which taking any part in the reasoning phase.




