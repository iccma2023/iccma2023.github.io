package aba.framework

/** Contrary class.
 *
 * @param assumption assumption.
 * @param contrary contrary of the assumption.
 */
case class Contrary(assumption: String, contrary: String)
