package aba

package object framework {

  val ArrowSign: String = "←"

}
