# ASPforABA
**ICCMA'23 version**

## Installing
1. Compile clingo with the instructions found in clingo-5.6.2/INSTALL.md (compile into aspforaba/clingo/ to skip step 3)
2. Install the required python libraries by running 
`pip install --no-index --find-links libraries/ -r requirements.txt`
3. Optionally, manually configure the location of the clingo binary and temporary files by running ./configure 

## Usage and input format
Run `./aspforaba -f <input_file> -p <problem> [-a <query>]`

This format complies with the [specification of ICCMA 2023](https://iccma2023.github.io/rules.html). ASPforABA supports each problem for the ABA track (DC-{CO|ST}, DS-{PR|ST}, SE-{PR|ST}).

### Author
Tuomo Lehtonen, University of Helsinki. For questions or comments, contact firstname.lastname@helsinki.fi.

### Other versions
For the other versions of ASPforABA, including other covered problems, see [the branch papers of this repository](https://bitbucket.org/coreo-group/aspforaba/src/72516a3d9c6a19db5c2d6b3800d41cd70c6f51b3/?at=release%2Fpapers).