static std::vector<std::string> const g_paths = {};
