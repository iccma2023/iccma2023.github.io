## Meta Encodings

Generic meta encodings used by some of the examples in the reify folder.
