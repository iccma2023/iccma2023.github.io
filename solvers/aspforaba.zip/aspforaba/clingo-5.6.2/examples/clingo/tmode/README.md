# Modeling Transition Systems

This example is similar to clingo's incremental mode but additionally takes
care of attaching a time parameter to atoms.

# Example Calls

    python tmode.py example.lp
