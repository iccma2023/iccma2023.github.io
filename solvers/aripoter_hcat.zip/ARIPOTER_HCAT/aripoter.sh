#!/bin/bash
java -Xint -XX:+UseSerialGC -jar $(dirname "$0")/ARIPOTER_HCAT.jar $@
