package appx.task;

public enum Semantics {
	PR, ST, SST, STG, ID, CO, GR
}
