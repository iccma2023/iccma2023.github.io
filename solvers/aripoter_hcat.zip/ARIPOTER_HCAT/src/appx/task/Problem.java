package appx.task;

public enum Problem {
	DS, DC, SE
}
