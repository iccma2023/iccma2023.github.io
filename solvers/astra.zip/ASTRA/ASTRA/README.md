
## ASTRA - Assumption-based argumentation Solver using Tree-decompositions to Answer reasoning tasks

ASTRA is an assumption-based argumentation (ABA) solver that exploits tree-decompositions for reasoning. The solver takes as input an ABA framework input file in the format specified by ICCMA23, a task with possibly a query, and outputs the result, again as defined by ICCMA23.

Under the hood, ASTRA makes use of DFLAT, a framework that allows solving reasoning tasks using dynamic programming, by specifying the dynamic programming algorithm in ASP. This algorithm is executed on a tree-decomposition of the problem instance.

The submitted package consists of the following:

- the python solver (astra.py)
- ABA encodings on tree decompositions for DFLAT (folder Encodings)
- D-FLAT binaries (also available at https://dbai.tuwien.ac.at/proj/dflat/system)
- example input instance (iccma_instance.txt)

## How to run

The solver was developed and tested with Python 3.

According to the ICCMA23 solver requirements, the following are all valid/supported ways to call the solver on an instance given in "iccma format" (from the solver directory):

* python astra.py

* python astra.py --problems

* python astra.py -p <task> -f path_to_instance/instance [-a query]

* ./astra.py -p <task> -f path_to_instance/instance [-a query]

    * supported tasks are DC-CO, DC-ST, DS-CO, DS-ST, SE-CO, SE-ST
    * for all tasks except SE-CO and SE-ST, a query has to be provided (an atom in the input ABA framework)

You can also call the solver from other directories as follows:

* ./path_to_astra/astra.py -p <task> -f path_to_instance/instance [-a query]

## D-FLAT

The submission includes the pre-compiled D-FLAT library (also available at: https://dbai.tuwien.ac.at/proj/dflat/system/).
