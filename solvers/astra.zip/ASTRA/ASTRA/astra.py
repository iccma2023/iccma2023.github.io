#!/usr/bin/env python3
from operator import index
import sys
import re
import subprocess
from subprocess import *
import pathlib
import tempfile
import os

#FUNCTIONS-------------------------------------------------------
#
def parse_instance(instance): #parse iccma instance to dflat instance
    f = open(instance, "r")
    p_line = f.readline()
    first_line = p_line.split(" ")
    n_sentences = int(first_line[2])
    #print("nsetnces", n_sentences)
    

    for line in f:
        arr = line.split(' ')
        arr[-1] = arr[-1].strip("\n")
        if "#" not in arr: 
            if arr[0] == "a": # assumption
                assumptions.append(arr[1])
            if arr[0] == "c": # contrary
                contraries.append([arr[1], arr[2]])
            if arr[0] == "r":
                rule = []
                for j in range(1, len(arr)):
                    rule.append(arr[j])
                rules.append(rule)
            # rule 

    for i in range(len(assumptions)+1, n_sentences+1):
        atoms.append(str(i))
   

    df_instance = tempfile.NamedTemporaryFile(mode="w+t")
    #df_instance_old = open("dflat_instance.lp", "w")
    #df_instance = open("dflat_instance.lp", "w")


    for a in assumptions:
        df_instance.writelines("assumption("+a+")."+"\n")
    for s in atoms:
        df_instance.writelines("atom("+s+")."+"\n")
    i = 0
    for r in rules:
        df_instance.writelines("rule(r"+str(i)+")."+"\n")
        df_instance.writelines("head(r"+str(i)+","+r[0]+").\n")
        for sentence in r[1:]:
            df_instance.writelines("body(r"+str(i)+","+sentence+").\n")
        i+=1
    for c in contraries:
        df_instance.writelines("contrary("+c[0]+","+c[1]+").\n")
    #df_instance.close()

    return df_instance

# append the query to the problem instance
def add_query_to_instance(df_instance, query):
    #df_instance = open("dflat_instance.lp", "a")
    df_instance.writelines("query("+query+").\n")

    return df_instance

# [[asm1,asm3,at2],[asm1],[asm2,at3]] ->[[asm1,asm3],[asm1],[asm2]] 
def only_assumptions(output_in):
    assm_in = []
    #only keep assumptions
    for solution in output_in:
        line = []
        for inelem in solution:
            if not inelem in atoms:
                line.append(inelem)
        assm_in.append(line)
    return assm_in

#END-FUNCTIONS---------------------------------------------------------

#SOLVER----------------------------------------------------------------
if len(sys.argv) == 1: # if nothing passed to solver.py
    print("ASTRA - Assumption-based argumentation Solver using Tree-decompositions to Answer reasoning tasks")
    print("Andrei Popescu - andrei.popescu@ist.tugraz.at ")
    print("Johannes P. Wallner - wallner@ist.tugraz.at")
    exit()
if "--problems" in sys.argv: # if --problems passed
    print("[DC-CO, DC-ST, DS-CO, DS-ST, SE-CO, SE-ST]")
    exit()

#we only solve DS and DC reasoning tasks, so we can already exit if -a not present
if "-p" not in sys.argv or "-f" not in sys.argv: # if -p or -f absent
    print("Wrong usage: arguments -p, and -f are required.")

else: #if -p and -f not absent
    problems = ["DC-CO", "DC-ST", "DS-CO", "DS-ST", "SE-CO", "SE-ST"]
    index_program = sys.argv.index("-p") + 1
    index_instance = sys.argv.index("-f") + 1

    task = sys.argv[index_program]
    instance = sys.argv[index_instance]
    
    if task not in problems:
        print("Pick a problem the solver can solve.")
        exit()

    if task not in ["SE-CO", "SE-ST"] and "-a" not in sys.argv:
        print("A query is required for this task. You can add -a query in the solver call")
        exit()

    assumptions = []
    atoms = [] #sentences that are not assumptions
    rules = []
    contraries = []

    df_instance = parse_instance(instance)
   
    
    #maybe check if the query is a valid sentence.
    if task not in ["SE-CO", "SE-ST"]:
        index_query = sys.argv.index("-a") + 1
        query = sys.argv[index_query]
        df_instance = add_query_to_instance(df_instance, query)

    df_instance.flush()
    #df_instance.close()
    temp_file_path = os.path.abspath(df_instance.name) 
    #df_instance.read()
    #printing content of temporary file
    #with open(df_instance.name, 'r') as df_instance_read:
    #    print("Temporary File Content:")
    #    print(df_instance_read.read())

    script_location = pathlib.Path(__file__).resolve().parent
    #print("script location", script_location)
    dflat_binary = script_location / "dflat-1.2.5-x86_64/dflat"
    encodings_path = script_location / "Encodings"


    if task == "DS-CO":
        process = subprocess.Popen([dflat_binary,"-p",encodings_path / "DS_CO.lp", "-f", temp_file_path, "--depth", "0"], stdout= subprocess.PIPE)
    if task == "DS-ST":
        process = subprocess.Popen([dflat_binary,"-p",encodings_path / "DS_ST.lp", "-f", temp_file_path, "--depth", "0"], stdout= subprocess.PIPE)
    if task == "DC-CO":
        process = subprocess.Popen([dflat_binary,"-p",encodings_path / "DC_CO.lp", "-f", temp_file_path, "--depth", "0"], stdout= subprocess.PIPE)
    if task == "DC-ST":
        process = subprocess.Popen([dflat_binary,"-p",encodings_path / "DC_ST.lp", "-f", temp_file_path, "--depth", "0"], stdout= subprocess.PIPE)
    if task == "SE-CO":
        process = subprocess.Popen([dflat_binary,"-p",encodings_path / "Complete.lp", "-f", temp_file_path], stdout= subprocess.PIPE)
    if task == "SE-ST":
        process = subprocess.Popen([dflat_binary,"-p",encodings_path / "Stable.lp", "-f", temp_file_path], stdout= subprocess.PIPE)
    
    
    
    
    output = str(process.communicate()[0], "utf-8") #the output is in process.communicate()[0] and we need it in utf-8 for parsing
    #print(output.partition("Solutions:")[2])
    if "Solutions" in output:
        output = str(output.partition("Solutions:")[2]) #get what comes after "Solutions:"
    else:
        output = "D-FLAT error"

    if task not in ["SE-CO", "SE-ST"]:
        #print("output all chars:",output)
        if output != "D-FLAT error":
            output = re.sub('\D', '', output) #only keep digit chars


    if task == "DS-CO" or task == "DS-ST":
        #if int(list(output)[0]) == 0:
        if output != "D-FLAT error":
            if int(output[0]) == 0:
                print("YES")
            else:
                print("NO")
        else:
            print(output)
    
    if task == "DC-CO" or task == "DC-ST":
        if output != "D-FLAT error":
            if int(list(output)[0]) > 0:
                print("YES")
            else:
                print("NO")
        else:
            print(output)

    if task == "SE-CO" or task == "SE-ST":
        #print("first element", output[0])
        output = output.splitlines()
        output = list(filter(None, output)) #removed empty strings from the output

        #level2 solutions are ┃  ┗━ or    ┗━
        # remove second level solutions
        for line in output:
            line.strip()
            if "  ┗━" in line or line=='' or "┃  ┗━" in line:
                output.remove(line)
        
        output_list = [] #array of arrays (instead of array of strings)
        for line in output:
            output_list.append(line.split())


        # IN sets
        output_in = [] #only keep what is IN (i.e. check what is a number -that is how we represented in)
        for line in output_list:
            in_set = []
            for elem in line:
                if elem.isnumeric():
                    in_set.append(elem)
            output_in.append(in_set)
        assumptions_in = only_assumptions(output_in)

        
        if len(assumptions_in) > 0:
            print("w", *assumptions_in[0])
        else:
            print("NO")
    
  
    """

    
    
    #print("index_program", path_program, "  index instance", path_instance)

    """
#END-SOLVER--------------------------------------------------------------
