# AcbAr 
**Atomic-based Argumentation solver**

**ICCMA'23 version**

## Installing
1. Compile mu-toksia by running `./build` in mu-toksia-multiquery/
2. Optionally, provide a directory for temporary files and the location for the AF solver by running ./configure 

## Usage and input format
Run `./acbar.py -f <input_file> -p <problem> [-a <query>]`

This format complies with the [specification of ICCMA 2023](https://iccma2023.github.io/rules.html). AcbAr supports each problem for the ABA track (DC-{CO|ST}, DS-{PR|ST}, SE-{PR|ST}).

## Reference
For more information and citing, please refer to

Tuomo Lehtonen, Anna Rapberger, Markus Ulbricht, Johannes P Wallner. [Argumentation Frameworks Induced by Assumption-based Argumentation: Relating Size and Complexity](https://proceedings.kr.org/2023/43/). KR 2023, pages 440-450.

The paper, including an online-only appendix, [is also included in this repository](https://bitbucket.org/lehtonen/acbar/src/master/KR23_paper_including_appendix.pdf).

## Author
Tuomo Lehtonen, University of Helsinki. For questions or comments, contact firstname.lastname@helsinki.fi.
