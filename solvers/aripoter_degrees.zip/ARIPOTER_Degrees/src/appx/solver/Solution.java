package appx.solver;

public interface Solution {
	
}
