#!/bin/bash
$(dirname "$0")/taas-fargo -limit 500 $@
